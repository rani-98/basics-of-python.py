#pass or fail 
grade = str(input("enter your grade : "))
if grade == ("A"):
    print("passed")
elif grade == ("B"):
    print("passed")
elif grade == ("c"):
    print("passed")
elif grade == ("D"):
    print("passed")
elif grade == ("F"):
    print("failed")

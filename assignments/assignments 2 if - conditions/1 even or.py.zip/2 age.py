age = int(input("enter age :"))
if   age <18:
    print("your are a minor")
elif age >=18:
    print("your are an older")



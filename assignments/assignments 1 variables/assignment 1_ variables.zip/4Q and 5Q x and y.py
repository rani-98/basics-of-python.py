#x and y valus
x = 2
y = 5
print(int(x))
print(int(y))

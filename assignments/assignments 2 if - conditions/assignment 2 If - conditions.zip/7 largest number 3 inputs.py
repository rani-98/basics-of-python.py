#largest number
num1 = int(input("enter number 1 :"))
num2 = int(input("enter number 2 :"))
num3 = int(input("enter number 3 :"))
if  num1>num2:
    print("largest number",num1)
elif num2>num3:
    print("largest number",num2)
elif num3>num1:
    print("largest number",num3)
    
    

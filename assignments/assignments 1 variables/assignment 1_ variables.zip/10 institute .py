institute = "BEST IT ACADEMY"
print(institute)

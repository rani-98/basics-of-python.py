vowels = str(input("enter character : "))
if vowels == 'a' or vowels == 'e' or vowels == 'i' or vowels == 'o' or vowels == 'u':
    print("it is a vowel")
else:
    print("it is a consonant")

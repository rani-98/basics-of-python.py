year = int(input("enter year: "))
if year % 400==0:
    print("this is leap year")
elif year % 4== 0:
    print("it is leap year")
else :
    print("it is  not a leap year")

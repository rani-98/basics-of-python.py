#Create a python file wich prints Hello World
a= "hello world !"
print(a.title())

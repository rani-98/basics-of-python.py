number = int(input("enter number :"))
if   number <0:
    print("it is negetive number")
elif number >0:
    print("it is positive number")
elif number == 0:
    print("it is zero")

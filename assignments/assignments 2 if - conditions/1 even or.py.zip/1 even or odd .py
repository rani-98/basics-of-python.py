number = int(input("enter number :"))
if   number % 2 == 0:
    print("it is even number")
elif number %2 != 0:
    print("it is odd number")
elif number == 0:
    print("it is zero")


#area triangle
base= int(input("enter base : "))
height=int(input("enter height : "))
area = (base*height)/2
if area > 50:
   print("it is large triangle", area)
elif area  < 50:
   print("it is small triangle", area)
          

#name and gender 
name = input("enter your name : ")
gender =input("enter your gender : ")
if gender == "M":
    print("hello", "Mr",name)
elif gender == "F":
    print("hello", "Ms", name)

age= int(input("enter age : "))
if age <= 12:
    print('$5')
elif age <= 65:
    print('$12')
elif age > 65:
    print('$7')

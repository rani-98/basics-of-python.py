#i am learning python
x = "I am "
y = "Learning "
z = "Python"
print(x + y + z)

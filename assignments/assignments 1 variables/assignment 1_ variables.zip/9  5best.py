#unsupported operand type(s) for +: 'int' and 'str'
x = "5"
y = "BEST"
print(x+y)

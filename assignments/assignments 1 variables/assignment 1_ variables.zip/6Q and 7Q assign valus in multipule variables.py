#assign values in multipul variables
print ("assign values in multipule variables")
a, b, c, d = 9, "rani", 4.6, "GOOD"
print(a)
print(b)
print(c)
print(d)
